package com.controller;

import com.dao.DepartmentDao;
import com.dao.EmployeeDao;
import com.model.Department;
import com.model.Employees;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet(name = "EmployeesServlet", urlPatterns = {"/EmployeesServlet"})
public class EmployeesServlet extends HttpServlet {

    //private static final long serialVersionUID = 1 L;

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private EmployeeDao employeeDao;
    private DepartmentDao departmentDao;

    public void init() {
        employeeDao = new EmployeeDao();
        departmentDao = new DepartmentDao();
    }

     protected void doPost(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
    	 System.out.println("post:" );
         doGet(request, response);
     }

     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         String action = request.getServletPath();
         System.out.println("get action:" + action);
         try {
             switch (action) {
                 case "/new":
                     showNewForm(request, response);
                     break;
                 case "/insert":
                     insertEmployee(request, response);
                     break;
                 case "/delete":
                     deleteEmployee(request, response);
                     break;
                 case "/edit":
                     showEditForm(request, response);
                     break;
                 case "/update":
                     updateEmployee(request, response);
                     break;
                 default:
                     listEmployee(request, response);
                     break;
             }
         } catch (SQLException | ParseException ex) {
             throw new ServletException(ex);
         }
     }

     private void listEmployee(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException, ServletException {
    	 List< Employees > listEmployee = employeeDao.getAllEmployees();
         request.setAttribute("listEmployee", listEmployee);
         RequestDispatcher dispatcher = request.getRequestDispatcher("employeeslist.jsp");
         dispatcher.forward(request, response);
     }

     private void showNewForm(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
         RequestDispatcher dispatcher = request.getRequestDispatcher("employeeForm.jsp");
         dispatcher.forward(request, response);
     }

     private void showEditForm(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, ServletException, IOException {
         int id = Integer.parseInt(request.getParameter("id"));
         Employees existingEmployee = employeeDao.getEmployeeById(id);
         RequestDispatcher dispatcher = request.getRequestDispatcher("employeeForm.jsp");
         request.setAttribute("Employee", existingEmployee);
         dispatcher.forward(request, response);

     }

     private void insertEmployee(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException, ParseException {
         String name = request.getParameter("name");
         String lastName = request.getParameter("lastName");
         Date dob = new SimpleDateFormat("dd/MM/yyyy").parse("dob");
         String email = request.getParameter("email");
         int deptid = Integer.parseInt(request.getParameter("departmetn_id"));
         Employees newEmployee = new Employees(name, lastName, dob, email, departmentDao.getDepartmentById(deptid));
         employeeDao.addEmployee(newEmployee);
         response.sendRedirect("list");
     }

     private void updateEmployee(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException, ParseException {
         String name = request.getParameter("name");
         String lastName = request.getParameter("lastName");
         Date dob = new SimpleDateFormat("dd/MM/yyyy").parse("dob");
         String email = request.getParameter("email");
         int deptid = Integer.parseInt(request.getParameter("departmetn_id"));
         Employees newEmployee = new Employees(name, lastName, dob, email, departmentDao.getDepartmentById(deptid));
         employeeDao.updateEmployee(newEmployee);
         response.sendRedirect("list");
     }

     private void deleteEmployee(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException {
         int id = Integer.parseInt(request.getParameter("id"));
         employeeDao.deleteEmployee(id);
         response.sendRedirect("list");
     }
}