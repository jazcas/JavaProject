package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.LoginMasterDao;
import com.model.LoginMaster;


@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
/**
 * Servlet implementation class Login
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 processRequest(request, response);
		
		
				 
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			 throws ServletException, IOException {	
		 String userId = request.getParameter("userId");	
		 String password = request.getParameter("password");
		
		 LoginMasterDao loginService = new LoginMasterDao(); 
		 boolean result = loginService.authenticate(userId, password); 
		 LoginMaster user = loginService.getUserById(userId);
		 
		 String userrole = user.getRole(); 
		 //boolean result = true;
		 if(result == true){
			 //request.getSession().setAttribute("user", user);	
			 if (userrole=="admin")
				 response.sendRedirect("adminHome.jsp");
			 else{
				 response.sendRedirect("userHome.jsp");
			 }
		 }
		 else{
			 response.sendRedirect("error.jsp");
		 }
	
	
	}

}
