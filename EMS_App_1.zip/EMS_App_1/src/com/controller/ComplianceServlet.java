package com.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.ComplianceDao;
import com.dao.DepartmentDao;
import com.dao.EmployeeDao;
import com.dao.ComplianceDao;
import com.model.Compliance;

/**
 * Servlet implementation class Compliance
 */
public class ComplianceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     * 
     * 
     */
    public ComplianceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    private ComplianceDao complianceDao;
    private DepartmentDao departmentDao;

    public void init() {
       
    	complianceDao = new ComplianceDao();
    	departmentDao = new DepartmentDao();
    }

     protected void doPost(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
    	 System.out.println("post:" );
         doGet(request, response);
     }

     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         String action = request.getServletPath();
         System.out.println("get action:" + action);
         try {
             switch (action) {
                 case "/new":
                     showNewForm(request, response);
                     break;
                 case "/insert":
                     insertCompliance(request, response);
                     break;
                 case "/delete":
                     deleteCompliance(request, response);
                     break;
                 case "/edit":
                     showEditForm(request, response);
                     break;
                 case "/update":
                     updateCompliance(request, response);
                     break;
                 default:
                     listCompliance(request, response);
                     break;
             }
         } catch (SQLException | ParseException ex) {
             throw new ServletException(ex);
         }
     }

     private void listCompliance(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException, ServletException {
    	 System.out.println("Compliances list");
         List< Compliance > listCompliances = complianceDao.getAllCompliances();
         request.setAttribute("listCompliance", listCompliances);
         RequestDispatcher dispatcher = request.getRequestDispatcher("Compliancelist.jsp");
         dispatcher.forward(request, response);
     }

     private void showNewForm(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
         RequestDispatcher dispatcher = request.getRequestDispatcher("Complianceform.jsp");
         dispatcher.forward(request, response);
     }

     private void showEditForm(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, ServletException, IOException {
         int id = Integer.parseInt(request.getParameter("id"));
         Compliance existingCompliance = complianceDao.getComplianceById(id);
         RequestDispatcher dispatcher = request.getRequestDispatcher("Complianceform.jsp");
         request.setAttribute("Compliance", existingCompliance);
         dispatcher.forward(request, response);

     }

	
	  private void insertCompliance(HttpServletRequest request, HttpServletResponse response)
			  throws SQLException, IOException, ParseException { 
		  String rlType =  request.getParameter("rlType"); 
		  String details =  request.getParameter("details");
		  Date createDate = (Date) new SimpleDateFormat("dd/MM/yyyy").parse("createdate");
		  int deptid = Integer.parseInt(request.getParameter("department_id"));
		  Compliance newCompliance = new Compliance(rlType, details, createDate, departmentDao.getDepartmentById(deptid));
		  complianceDao.addCompliance(newCompliance); 
		  response.sendRedirect("list"); 
	  }
	 

     private void updateCompliance(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException, ParseException {
    	 String rlType =  request.getParameter("rlType"); 
		 String details =  request.getParameter("details");
		 Date createDate = (Date) new SimpleDateFormat("dd/MM/yyyy").parse("createdate");
		 int deptid = Integer.parseInt(request.getParameter("department_id"));
		 Compliance newCompliance = new Compliance(rlType, details, createDate, departmentDao.getDepartmentById(deptid));
         complianceDao.updateCompliance(newCompliance);
         response.sendRedirect("list");
     }

     private void deleteCompliance(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException {
         int id = Integer.parseInt(request.getParameter("id"));
         complianceDao.deleteCompliance(id);
         response.sendRedirect("list");
     }

}
