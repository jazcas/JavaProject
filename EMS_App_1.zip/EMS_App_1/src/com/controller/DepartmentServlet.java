package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DepartmentDao;
import com.model.Department;


/**
 * Servlet implementation class DepartmentServlet
 */
public class DepartmentServlet extends HttpServlet {
	//private static final long serialVersionUID = 1L;
       
	
    private DepartmentDao departmentDao;

    public void init() {
       
        departmentDao = new DepartmentDao();
    }

     protected void doPost(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
    	 System.out.println("post:" );
         doGet(request, response);
     }

     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         String action = request.getServletPath();
         System.out.println("get action:" + action);
         try {
             switch (action) {
                 case "/new":
                     showNewForm(request, response);
                     break;
                 case "/insert":
                     insertDepartment(request, response);
                     break;
                 case "/delete":
                     deleteDepartment(request, response);
                     break;
                 case "/edit":
                     showEditForm(request, response);
                     break;
                 case "/update":
                     updateDepartment(request, response);
                     break;
                 default:
                     listDepartment(request, response);
                     break;
             }
         } catch (SQLException | ParseException ex) {
             throw new ServletException(ex);
         }
     }

     private void listDepartment(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException, ServletException {
    	 System.out.println("Departments list");
    	 List<Department> listDepartment = departmentDao.getAllDepartments();
         request.setAttribute("listDepartment", listDepartment);
         System.out.println("ListDepartment "+listDepartment);
         RequestDispatcher dispatcher = request.getRequestDispatcher("Department.jsp");
         dispatcher.forward(request, response);
     }

     private void showNewForm(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
         RequestDispatcher dispatcher = request.getRequestDispatcher("Department-form.jsp");
         dispatcher.forward(request, response);
     }

     private void showEditForm(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, ServletException, IOException {
         int id = Integer.parseInt(request.getParameter("id"));
         Department existingDepartment = departmentDao.getDepartmentById(id);
         RequestDispatcher dispatcher = request.getRequestDispatcher("Department-form.jsp");
         request.setAttribute("Department", existingDepartment);
         dispatcher.forward(request, response);

     }

	
	  private void insertDepartment(HttpServletRequest request, HttpServletResponse response)
			  throws SQLException, IOException, ParseException { 
		  int deptid =  Integer.parseInt(request.getParameter("departmentId")); 
		  String departmentName = request.getParameter("departmentName");		  
		  Department newDepartment = new Department(departmentName);
		  departmentDao.addDepartment(newDepartment); 
		  response.sendRedirect("list"); 
	  }
	 

     private void updateDepartment(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException, ParseException {
    	 String departmentName = request.getParameter("departmentName");
         Department newDepartment = new Department(departmentName);
         departmentDao.updateDepartment(newDepartment);
         response.sendRedirect("list");
     }

     private void deleteDepartment(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException {
         int id = Integer.parseInt(request.getParameter("id"));
         departmentDao.deleteDepartment(id);
         response.sendRedirect("list");
     }

}
