package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.ComplianceDao;
import com.dao.DepartmentDao;
import com.dao.EmployeeDao;
import com.dao.StatusReportDao;
import com.model.StatusReport;


/**
 * Servlet implementation class StatusReportServlet
 */
public class StatusReportServlet extends HttpServlet {
	//private static final long serialVersionUID = 1 L;

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private StatusReportDao statusReportDao;
    private DepartmentDao departmentDao;
    private EmployeeDao employeeDao;
    private ComplianceDao complianceDao;

    public void init() {
        statusReportDao = new StatusReportDao();
        departmentDao = new DepartmentDao();
        complianceDao = new ComplianceDao();
        employeeDao = new EmployeeDao();
    }

     protected void doPost(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
    	 System.out.println("post:" );
         doGet(request, response);
     }

     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         String action = request.getServletPath();
         System.out.println("get action:" + action);
         try {
             switch (action) {
                 case "/new":
                     showNewForm(request, response);
                     break;
                 case "/insert":
                     insertStatusReport(request, response);
                     break;
                 case "/delete":
                     deleteStatusReport(request, response);
                     break;
                 case "/edit":
                     showEditForm(request, response);
                     break;
                 case "/update":
                     updateStatusReport(request, response);
                     break;
                 default:
                     listStatusReport(request, response);
                     break;
             }
         } catch (SQLException | ParseException ex) {
             throw new ServletException(ex);
         }
     }

     private void listStatusReport(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException, ServletException {
    	 List< StatusReport > listStatusReport = statusReportDao.getAllStatusReports();
         request.setAttribute("listStatusReport", listStatusReport);
         RequestDispatcher dispatcher = request.getRequestDispatcher("regulationlist.jsp");
         dispatcher.forward(request, response);
     }

     private void showNewForm(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
         RequestDispatcher dispatcher = request.getRequestDispatcher("StatusReportForm.jsp");
         dispatcher.forward(request, response);
     }

     private void showEditForm(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, ServletException, IOException {
         int id = Integer.parseInt(request.getParameter("id"));
         StatusReport existingStatusReport = statusReportDao.getStatusById(id);
         RequestDispatcher dispatcher = request.getRequestDispatcher("StatusReportForm.jsp");
         request.setAttribute("StatusReport", existingStatusReport);
         dispatcher.forward(request, response);

     }

     private void insertStatusReport(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException, ParseException {
         String comments = request.getParameter("comments");
         Date createdate = new SimpleDateFormat("dd/MM/yyyy").parse("createdate");
         int deptid = Integer.parseInt(request.getParameter("departmetn_id"));
         int empid = Integer.parseInt(request.getParameter("empid"));
         int complianceid = Integer.parseInt(request.getParameter("complianceid"));
         int statusRptId = Integer.parseInt(request.getParameter("statusRptId"));
         StatusReport newStatusReport = new StatusReport(complianceDao.getComplianceById(complianceid), statusRptId,
        		 employeeDao.getEmployeeById(empid), comments,createdate, departmentDao.getDepartmentById(deptid)
        		 );
         statusReportDao.addStatusReport(newStatusReport);
         response.sendRedirect("list");
     }

     private void updateStatusReport(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException, ParseException {
    	 String comments = request.getParameter("comments");
         Date createdate = new SimpleDateFormat("dd/MM/yyyy").parse("createdate");
         int deptid = Integer.parseInt(request.getParameter("departmetn_id"));
         int empid = Integer.parseInt(request.getParameter("empid"));
         int complianceid = Integer.parseInt(request.getParameter("complianceid"));
         int statusRptId = Integer.parseInt(request.getParameter("statusRptId"));
         StatusReport newStatusReport = new StatusReport(complianceDao.getComplianceById(complianceid), statusRptId,
        		 employeeDao.getEmployeeById(empid), comments,createdate, departmentDao.getDepartmentById(deptid)
        		 );
         statusReportDao.updateStatusReport(newStatusReport);
         response.sendRedirect("list");
     }

     private void deleteStatusReport(HttpServletRequest request, HttpServletResponse response)
             throws SQLException, IOException {
         int id = Integer.parseInt(request.getParameter("id"));
         statusReportDao.deleteStatusReport(id);
         response.sendRedirect("list");
     }

}
