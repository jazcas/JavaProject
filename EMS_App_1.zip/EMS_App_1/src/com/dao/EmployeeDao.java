package com.dao;


import com.model.Employees;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import com.util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;


public class EmployeeDao {

    public void addEmployee(Employees employee) {
        Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();;
        try {
            trns = session.beginTransaction();
            session.save(employee);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
           session.close();
        }
    }

    public void deleteEmployee(int empid) {
        Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            Employees employee = (Employees) session.load(Employees.class,empid);
            session.delete(employee);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void updateEmployee(Employees employee) {
        Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            session.update(employee);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
    @SuppressWarnings("unchecked")
    public List<Employees> getAllEmployees() {
    	Configuration configuration = new Configuration().configure();
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().
		applySettings(configuration.getProperties());		
		SessionFactory factory = configuration.buildSessionFactory(builder.build());
    	List<Employees> employees = new ArrayList<Employees>();
        Transaction trns = null;
        //Session session = HibernateUtil.getSessionFactory().openSession();
        Session session=factory.openSession();
        try {
            trns = session.beginTransaction();
            employees = session.createQuery("from Employees").getResultList();
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return employees;
    }
    @SuppressWarnings("unchecked")
    public Employees getEmployeeById(int empid) {
        Employees employee = null;
        Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            Query query = session.createQuery("from com.model.Employees where empId = :empId");
            query.setParameter("empId",empid);


            employee = (Employees) query.uniqueResult();
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return employee;
    }

    public EmployeeDao() {
        // TODO Auto-generated constructor stub
    }


}
