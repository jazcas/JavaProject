package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.model.LoginMaster;
import com.util.HibernateUtil;

public class LoginMasterDao {
	
	public void addLogin(LoginMasterDao user) {
        Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            session.save(user);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void deleteLogin(int UserId) {
        Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            LoginMasterDao user = (LoginMasterDao) session.load(LoginMasterDao.class,UserId);
            session.delete(user);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void updateLogin(LoginMasterDao user) {
        Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            session.update(user);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public List<LoginMasterDao> getAllLogins() {
        List<LoginMasterDao> Users = new ArrayList<LoginMasterDao>();
        Transaction trns = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            Users = session.createQuery("from LoginMaster ").list();
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return Users;
    }
    @SuppressWarnings("unchecked")
    public LoginMaster getUserById(String userId) {
    	
        Session session = HibernateUtil.getSessionFactory().openSession();
   	 	Transaction tx = null;
   	 	LoginMaster User = null;
	   	try {
	   		 tx = session.getTransaction();
	   		 tx.begin();
	   		 Query query = session.createQuery("from LoginMaster where userid='"+userId+"'");
	   		User = (LoginMaster)query.uniqueResult();
	   		 tx.commit();
	   	 } catch (Exception e) {
	   		 if (tx != null) {
	   			 tx.rollback();
	   		 }
	   		 e.printStackTrace();
	   	 } finally {
	   		 session.close();
	   	 }
	   	 return User;
	    }

    public boolean authenticate(String userId, String password) {
		
		  LoginMaster user = getUserById(userId); if(user!=null &&
		  user.getUserId().equals(userId) && user.getPassword().equals(password)){
		  return true; }else{ return false; }
		 
   	
   }
    

    public LoginMasterDao() {
        // TODO Auto-generated constructor stub
    }


}
